# Security Policy

## Supported Versions

This repository is not actively maintained but I try as much as I can to fix all reported vulnerabilities.

## Reporting a Vulnerability

To report a vulnerability, you can send me an email at amirsanni@gmail.com. Thank you.
